const express = require('express');
const router = express.Router();
const Recipe = require('../models/Recipe');


router.post('/', async (req, res) => {
  try {
    const recipe = new Recipe(req.body);
    await recipe.save();
    res.status(201).send(recipe);
  } catch (error) {
    res.status(400).send(error);
  }
});


router.get('/', async (req, res) => {
  try {
    const recipes = await Recipe.find();
    res.send(recipes);
  } catch (error) {
    res.status(500).send(error);
  }
});


router.get('/:id', async (req, res) => {
  try {
    const recipe = await Recipe.findById(req.params.id);
    if (!recipe) {
      return res.status(404).send({ message: 'Recipe not found' });
    }
    res.send(recipe);
  } catch (error) {
    res.status(500).send(error);
  }
});


router.patch('/:id', async (req, res) => {
  try {
    const recipe = await Recipe.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!recipe) {
      return res.status(404).send({ message: 'Recipe not found' });
    }
    res.send(recipe);
  } catch (error) {
    res.status(400).send(error);
  }
});


router.delete('/:id', async (req, res) => {
  try {
    const recipe = await Recipe.findByIdAndDelete(req.params.id);
    if (!recipe) {
      return res.status(404).send({ message: 'Recipe not found' });
    }
    res.send({ message: 'Recipe deleted successfully' });
  } catch (error) {
    res.status(500).send(error);
  }
});

module.exports = router;
