import React from 'react';
import RecipeList from './components/RecipeList';
import RecipeForm from './components/RecipeForm';
import './app.css';

function App() {
  return (
    <div>
      <h1>Recipe Book</h1>
      <RecipeForm />
      <RecipeList />
    </div>
  );
}

export default App;
