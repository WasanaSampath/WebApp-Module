import React from 'react';

const RecipeList = () => {
  
  return (
    <div>
      <h1>Recipe List</h1>
    </div>
  );
}

export default RecipeList;
