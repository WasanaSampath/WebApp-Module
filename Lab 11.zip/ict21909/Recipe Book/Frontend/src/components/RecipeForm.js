import React, { useState } from 'react';

const RecipeForm = () => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    ingredients: [],
    instructions: [],
    cookingTime: ''
  });

  const handleSubmit = (event) => {
    event.preventDefault();
    
    console.log(formData);
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <label htmlFor="name">Recipe Name:</label>
        <input type="text" id="name" name="name" required onChange={handleChange} /><br /><br />
        <input type="submit" value="Submit" />
      </form>
    </div>
  );
}

export default RecipeForm;
