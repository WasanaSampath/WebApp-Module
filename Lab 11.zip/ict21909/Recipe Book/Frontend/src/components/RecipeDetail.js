import React from 'react';

const RecipeDetail = ({ recipe }) => {
  
  return (
    <div>
      <ul>
            <li>Noodle</li>
            <li>egg</li>
            <li>Dhal curry dish</li>
            
    </ul>
    </div>
  );
}

export default RecipeDetail;
