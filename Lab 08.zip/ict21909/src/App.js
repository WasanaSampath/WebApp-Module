import logo from './logo.svg';
import { useState } from 'react';
import './App.css';

const App = () => {

  const [count, setCount] = useState(21909);

  return (<>
    <div className="App">
      <h1>SK Wasana Sampath</h1>

      <div className='but'>
        <button className='c1' onClick={() => setCount((prevCount) => prevCount - 100)}> - 100</button>
        <h1 className='ict'>ICT - </h1> <h1 className='ind'> {count}</h1>
        <button className='c1' onClick={() => setCount((prevCount) => prevCount + 100)}> + 100</button>
      </div>

    </div>
    <button onClick={() => setCount(21909)} className='res'>RESET</button>
  </>
  );
}

export default App;
