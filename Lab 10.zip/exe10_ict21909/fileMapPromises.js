//ICT/ 21/ 909- S.K. Wasana Sampath

const fs = require("fs").promises; // Importing fs module with promises
const path = require("path"); // Importing path module for handling file paths

// Function to read and process the contents of the input file
const processInputFile = async () => {
    try {
        // Read the contents of the input file asynchronously
        const data = await fs.readFile("./resources/inputict21909.txt", "utf-8");

        // Convert the data to uppercase
        const upp = data.toUpperCase();

        // Write the uppercase data to the output file
        await fs.writeFile("./resources/outputict21909.txt", upp);

        // Delete the input file
        await fs.unlink("./resources/inputict21909.txt");

        console.log("Processing completed successfully.");
    } catch (error) {
        console.error("Error occurred while processing:", error);
    }
};

// Main function to check file existence and execute processing
const main = async () => {
    try {
        // Check if the input file exists
        await fs.access("./resources/inputict21909.txt", fs.constants.F_OK);

        // Check if the output file exists
        await fs.access("./resources/outputict21909.txt", fs.constants.F_OK);

        // Execute the processing function if both files exist
        await processInputFile();
    } catch (error) {
        console.error("Error occurred:", error);
    }
};

// Execute the main function
main();
