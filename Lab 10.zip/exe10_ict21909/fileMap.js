//ICT/ 21/ 909- S.K. Wasana Sampath

const fs = require("fs");// Importing fs module
// Function to read and process the contents of the input file
fs.readFile("./resources/inputict21909.txt", "utf-8", (err, data) => {
  if (err) throw err;
  console.log(data);

  // Convert the data to uppercase
  const upp = data.toUpperCase();

  // Append the uppercase data to the output file
  fs.appendFile("./resources/outputict21909.txt", upp, (err) => {
    if (err) throw err;
    console.log("Done");
  });

   // Delete the input file
  fs.unlink("./resources/inputict21909.txt", (err) => {
    if (err) throw err;
    console.log("Done");
  });
});

//error handling
process.on("uncaughtException", (err) => {
  console.error("Error: ${err}");
  process.exit(1);
});
