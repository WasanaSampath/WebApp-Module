//1
let str = "ICT/ 21/ 909";
let num = 223;
let bool = true;
let arr = [1, 2, 3];
let obj = { key: 'value' }

// 2
let c = num + 2;  //'num' is in 1.
let a = c * 2;
let b = a - 5;
let d = b / 3;
let dd = b % 3;
let e = d ** 2;

console.log(a, b, c, d, dd, e);

//3
let str2 = '_Sampath';
let result = str + str2;  //'str' from 1.

//4
if (bool) {
    console.log("this is true"); //'bool' from 1.

} else {
    console.log("this is false");
}

//5
for (var i = 0; i < arr.length; i++) {
    console.log("element " + i + " is " + arr[i]); //'arr' from 1.
}

//6
function area(length, width) {
    let ca = length * width;
    return ca;
}

let squ = area(45, 30);
console.log("Area of the rectangle is " + squ);

//7
document.getElementById("col").addEventListener('click', function () {
    document.body.style.backgroundColor = getColor();
});

function getColor() {
    let spel = '0123456789ABCDEF';
    let color = '#';
    for (var i = 0; i < 6; i++) {
        color += spel[Math.floor(Math.random() * 16)];
    }
    return color;
}

